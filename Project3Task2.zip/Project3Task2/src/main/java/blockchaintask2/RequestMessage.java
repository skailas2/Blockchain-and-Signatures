package blockchaintask2;

public class RequestMessage {
    private String id, e, n, command, data, signature;

    public RequestMessage(String id, String e, String n, String command, String data, String signature) {
        this.id = id;
        this.e = e;
        this.n = n;
        this.command = command;
        this.data = data;
        this.signature = signature;
    }

    public String getId() { return id; }
    public String getE() { return e; }
    public String getN() { return n; }
    public String getCommand() { return command; }
    public String getSignature() { return signature; }
}
