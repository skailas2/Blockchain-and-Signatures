package blockchaintask2;

/**
 * Represents the server's response to the client.
 */
public class ResponseMessage {
    private String response;

    public ResponseMessage(String response) {
        this.response = response;
    }

    public String getResponse() {
        return response;
    }
}
